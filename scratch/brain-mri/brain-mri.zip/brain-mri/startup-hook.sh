pip install sklearn
pip install opencv-python-headless